package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText dateText, timeText;
    ImageButton datePick, timePick;
    Button applyBtn,openCustom;
    Dialog dialog2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dateText = findViewById(R.id.editTextDate);
        timeText = findViewById(R.id.editTextTime);

        datePick = findViewById(R.id.imageButton);
        timePick = findViewById(R.id.imageButton2);
        applyBtn = findViewById(R.id.button);



        datePick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedYear = 2060;
                int selectedMonth = 2;
                int selectedDay = 2;
                DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int i, int i1, int i2) {
                        dateText.setText(""+ i+ "-"+(i1-1)+ "-"+i2);
                    }
                };
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                        dateSetListener,selectedYear,selectedMonth,selectedDay);
                datePickerDialog.show();
            }
        });
        timePick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean is24HView = true;
                int selectedHour = 10;
                int selectedMinute = 20;
                TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        timeText.setText(hourOfDay + ":" + minute);
                    }
                };
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this,
                        timeSetListener,selectedHour,selectedMinute,is24HView);
                timePickerDialog.show();
            }

        });
        applyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Подтверждение записи")
                        .setMessage("Вы подтверждаете свою запись")
                        .setPositiveButton("Подтвердить", new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface,int i){
                                dialogInterface.cancel();
                                Toast.makeText(MainActivity.this, "Ваша запись подтверждена", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Отменить", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                dialog.dismiss();
                                Toast.makeText(MainActivity.this, "Ваша запись была отменена", Toast.LENGTH_SHORT).show();

                            }
                        })
                        .create();
                builder.show();
            }
        });
    }

}